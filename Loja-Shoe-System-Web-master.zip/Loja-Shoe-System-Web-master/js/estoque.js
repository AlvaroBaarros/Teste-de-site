

function incluirEstoque(){
    location = "../produtos.html"
}
